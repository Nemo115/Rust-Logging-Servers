pub mod utils;
pub use utils::*;

// Commands the client sends to the daemon
pub enum DaemonCommand{
    Log {name: String},
}

pub enum DaemonResponse{
    Ok,
    Err(String),
    List {items:Vec<String>},
}