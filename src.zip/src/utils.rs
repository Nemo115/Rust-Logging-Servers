use std::collections::HashMap;
use std::{io::Read, process::Command};
use chrono;
use log::LevelFilter;
use std::fs::create_dir_all;
use std::fs::remove_dir_all;
use std::fs::read_dir;

const LOG_FOLDER: &str = "Logs/";
const ROTATION_MONTHS: u32 = 2;

pub fn log_system(){
    // Create and rotate log files
    let cur_time = new_log_file(); // Create new log file and pass on the current date time
    del_old_logs(&cur_time, ROTATION_MONTHS); // Rotate and delete past log files
    
    // Get list of containers
    let container_list = lxc_list();
    log::info!("CONTAINER LIST: {:?}", container_list);
    log::info!("OUTPUT: {:?}", storage_pool_status());

    // Log for each container
    for container in container_list {
        let current_container = &container["NAME"];
        log::info!("OUTPUT: {:?}", lxc_ps_aux(current_container));
        log::info!("OUTPUT: {:?}", lxc_info(current_container));
        log::info!("OUTPUT: {:?}", integrity_disk_space(current_container));
    }

    // Call to sleep for four hours
    println!("Logged status");
}


// Create new log file in directory for the current time
pub fn new_log_file() -> Vec<String>{
    let dt = chrono::offset::Utc::now().to_string(); // 2025-07-24T08:08:26.280253665Z
    let dt_values: Vec<String> = dt.split(&['-', '.', ' '])
                                    .filter(|&r| r != "")
                                    .map(|v| v.to_string())
                                    .collect(); // 2025-07-25 07:04:58.302342296 UTC -> ["2025", "07", "25", "07:04:58", "302342296", "UTC"]
    //println!("{} -> {:?}", dt, dt_values);
    let year = &dt_values[0];
    let month = &dt_values[1];
    let day = &dt_values[2];
    let time = &dt_values[3];

    let dir_path = LOG_FOLDER.to_string() + year + "/" + month + "/" + day;
    let file_name = dir_path.clone() + "/" + time +".log";
    
    // Create directory
    match create_dir_all(dir_path) {
        Ok(_) => println!("Successfully created {}", file_name),
        Err(e) => eprint!("Failed to create directory: {}", e)
    }
    simple_logging::log_to_file(file_name, LevelFilter::Info).unwrap();

    dt_values
}

fn del_dir(dir: &str, time_cutoff: u32) {
    let paths = read_dir(dir).unwrap();
    for path in paths{
        let cur_dir = path.unwrap().path().display().to_string();
        let time: u32 = cur_dir.replace(dir, "").parse().unwrap();
        if time < time_cutoff { // Remove the entire directory
            match remove_dir_all(&cur_dir) {
                Ok(_) => println!("Successfully deleted directory {}", cur_dir),
                Err(e) => eprint!("Failed to delete directory {}: {}", cur_dir, e)
            }
        }
    }
}

// This some messy code
pub fn del_old_logs(today: &Vec<String>, threshold: u32) {
    let cur_year: u32 = today[0].to_string().parse().unwrap();
    let cur_month: u32 = today[1].to_string().parse().unwrap();
    let month_cutoff = cur_month - threshold;
    
    // Scan years first - delete any previous years
    del_dir(LOG_FOLDER, cur_year);

    // Now scan months and delete any months below the cutoff
    let months_dir = LOG_FOLDER.to_owned() + &cur_year.to_string() + "/";
    del_dir(&months_dir, month_cutoff);
}

// Helper function for lxd commands
// parameters: lxc [list of strings]
fn lxc_command(args: &[&str]) -> String{
    let mut lxc_call = Command::new("lxc");
    for arg in args{
        lxc_call.arg(arg);
    }
    
    lxc_call.stdin(std::process::Stdio::piped());
    lxc_call.stdout(std::process::Stdio::piped());

    let mut call_output = lxc_call.spawn().unwrap(); // output handle
    _ = call_output.wait();
    let mut output_buffer = String::new();
    _ = call_output.stdout.unwrap().read_to_string(&mut output_buffer);

    //println!("output:\n{}", output_buffer);

    log::info!("CALLED COMMAND: lxc {:?}", args);

    output_buffer
}

// read and extract output of ps -- aux 
fn parse_ps_aux(output: &str) -> Vec<HashMap<String, String>> {
    let mut processes = Vec::new();
    let mut lines = output.lines();

    let headers = ["USER", "PID", "%CPU", "%MEM", "VSZ", "RSS", "TTY", "STAT", "START", "TIME"];

    // Skip the header line (if it exists)
    if output.starts_with("USER") {
        lines.next();
    }

    for line in lines {
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() >= 11 {
            let mut process = HashMap::new();
            for i in 0..10 {
                process.insert(headers[i].to_string(), fields[i].to_string());
            }
            process.insert("COMMAND".to_string(), fields[10..].join(" ")); // Handle spaces in COMMAND
            processes.push(process);
        }
    }
    processes
}

// For reading terminal outputs that are in the form of tables
// Cannot be used for columns with spaces within values (refer to other helper functions or custom code)
fn parse_tabular_data_table(output: &str) -> Vec<HashMap<String, String>>{
    let mut rows = Vec::new();
    let mut lines = output.lines();

    // Read and collect the headers
    let mut headers = Vec::new();
    let mut count = 0;

    for line in lines {
        let mut fields: Vec<&str> = line.split_whitespace().collect();
        if count == 0 { // Define the headers as the key values
            headers.append(&mut fields);
        }
        else {
            let mut row = HashMap::new();
            for i in 0..fields.len() {
                row.insert(headers[i].to_string(), fields[i].to_string());
            }
            rows.push(row);
        }
        count+=1;
    }
    rows
}

fn parse_box_data_table(output: &str) -> Vec<HashMap<String, String>>{
    const SKIP_ROWS: usize = 1;

    let mut headers  = Vec::new();
    let mut data_rows: Vec<HashMap<String, String>> = Vec::new(); // Vec of Hashmaps - [{"Name": XXX, "State": XXX, "IPV4": XXX}, {"Name": XXX, "State": XXX, "IPV4": XXX}, ...]
    let mut count = 0;

    for line in output.lines().skip(SKIP_ROWS) {
        if !line.starts_with('|') {
            continue;
        }
        let mut columns: Vec<&str> = line.split('|').map(|s| s.trim()).collect();
        
        if count == 0 { // collect the headers
            headers.append(&mut columns);
        }
        else{
            let mut row: HashMap<String, String> = HashMap::new();
        
            for (idx, header) in headers.iter().enumerate(){
                row.insert(header.to_string(), columns[idx].to_string());
            }
            
            data_rows.push(row);
        }
        count += 1;
    }
    data_rows
}

// Container status check
pub fn lxc_list() -> Vec<HashMap<String, String>>{
    let output: String = lxc_command(&["list"]);

    // String Manipulation
    // Read each line and store values into dictionary array
    const SKIP_ROWS: usize = 2;
    const SKIP_ITEM: usize = 1;

    let headers  = ["NAME", "STATE", "IPV4", "IPV6", "TYPE", "SNAPSHOTS"];
    let mut data_rows: Vec<HashMap<String, String>> = Vec::new(); // Vec of Hashmaps - [{"Name": XXX, "State": XXX, "IPV4": XXX}, {"Name": XXX, "State": XXX, "IPV4": XXX}, ...]

    for line in output.lines().skip(SKIP_ROWS) {
        if line.starts_with('|'){
            let columns: Vec<&str> = line.split('|').map(|s| s.trim()).collect();
            let mut row: HashMap<String, String> = HashMap::new();
            
            for (idx, header) in headers.iter().enumerate(){
                row.insert(header.to_string(), columns[idx + SKIP_ITEM].to_string());
            }
            
            data_rows.push(row);
        }
    }
    data_rows
}

// Resource Usage
pub fn lxc_info(container_name: &str) -> HashMap<String, String>{
    let output = lxc_command(&["info", container_name]);

    let mut data = HashMap::new();

    // Read first 7 lines of data
    for line in output.lines().take(7) {
        if let Some((key, value)) = line.split_once(':') {
            let key = key.trim().to_string();
            let value = value.trim().to_string();
            data.insert(key, value);
        }
    }
    
    log::info!("DATA: {:?}", data);

    // If container is running extract more data

    // If snapshots exist, read snapshots

    data
}

// Container Process Health
pub fn lxc_ps_aux(container_name: &str) -> Vec<HashMap<String, String>>{
    let output = lxc_command(&["exec", container_name, "--", "ps", "aux"]);
    let processes: Vec<HashMap<String, String>> = parse_ps_aux(&output);
    processes
}

// Network Connectivity - investigate what this does
pub fn network_connectivity(container_name: &str){
    lxc_command(&["exec", container_name, "--", "ping", "-c", "3", "8.8.8.8"]);

}

// File System Integrity and Disk Space
pub fn integrity_disk_space(container_name: &str) -> Vec<HashMap<String, String>>{
    let output = lxc_command(&["exec", container_name, "--", "df", "-h"]);
    //lxc_command(&["exec", container_name, "--", "du", "-sh", "/var/log"]); // Check for specific directory
    let data = parse_tabular_data_table(&output);
    data
}

// Log File Health
pub fn log_file_health(container_name: &str){
    let output = lxc_command(&["exec", container_name, "--", "tail", "-n", "100", "/var/log/syslog"]);
    // Understand the data output
}

// LXD Storage Pool Status
pub fn storage_pool_status() -> Vec<HashMap<String, String>>{
    let output = lxc_command(&["storage", "list"]);
    let data = parse_box_data_table(&output);
    data
}

// Network Interface and DNS
pub fn network_interface_dns(container_name: &str){
    lxc_command(&["exec", container_name, "--", "ip", "a"]);
    lxc_command(&["exec", container_name, "--", "cat", "/etc/resolv.conf"]);
    // ifconfig
}

// Backup Verification
pub fn backup_verification(container_name: &str){
    lxc_command(&["exec", container_name, "backup.tar.gz"]);
}

// Snapshot Management
pub fn snapshot_management(container_name: &str){
    lxc_command(&["snapshot", container_name]);
    lxc_command(&["info", container_name]);
}